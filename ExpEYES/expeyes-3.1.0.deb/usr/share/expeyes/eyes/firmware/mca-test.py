import expeyes.mca
p=expeyes.mca.open()

print 'MCA version ->', p.get_version()

